import React, { useEffect, useState } from 'react';
import './TopUsers.css';

const TopUsers = () => {
  const [topUsers, setTopUsers] = useState([]);

  useEffect(() => {
    const fetchTopUsers = async () => {
      try {
        const response = await fetch('http://20.244.56.144/test/users', {
          headers: {
            'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJNYXBDbGFpbXMiOnsiZXhwIjoxNzQyNjI0NzI2LCJpYXQiOjE3NDI2MjQ0MjYsImlzcyI6IkFmZm9yZG1lZCIsImp0aSI6IjE2NWJmMmUwLTNmMzItNDJiNC1hNTYzLTcxYWZiZGEwMzQ0MiIsInN1YiI6Im1lZW5ha3NoaS5rYW1ha29sYW51LjIyY3NlQGJtdS5lZHUuaW4ifSwiY29tcGFueU5hbWUiOiJBZmZvcmQiLCJjbGllbnRJRCI6IjE2NWJmMmUwLTNmMzItNDJiNC1hNTYzLTcxYWZiZGEwMzQ0MiIsImNsaWVudFNlY3JldCI6IlZLRkNndkRueHVrdWVDdXAiLCJvd25lck5hbWUiOiJNZWVuYWtzaGkiLCJvd25lckVtYWlsIjoibWVlbmFrc2hpLmthbWFrb2xhbnUuMjJjc2VAYm11LmVkdS5pbiIsInJvbGxObyI6IjIyMDM2OSJ9.0OZLG8151Cl18IXOAvgVNR1Pce_G_s3h0AH1SLCnN-A',
            'Content-Type': 'application/json',
          },
        });

        const data = await response.json();
        console.log("API Response:", data);

        if (data.users && Array.isArray(data.users)) {
            const usersArray = Object.values(data.users);
          setTopUsers(usersArray.slice(0, 5)); // Display top 5 users
        } else {
          console.error("Unexpected data format", data);
        }
      } catch (error) {
        console.error('Error fetching top users:', error);
      }
    };

    fetchTopUsers();
    const interval = setInterval(fetchTopUsers, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="top-users-container">
      <h2>🏆 Top Users</h2>
      <ul className="top-users-list">
        {topUsers.length > 0 ? (
          topUsers.map((user, index) => (
            <li key={index} className="top-user">
              <span className="rank">#{index + 1}</span> 
              <span className="name">{user.user}</span> 
              <span className="score">⭐ {user.score}</span>
            </li>
          ))
        ) : (
          <p>Loading top users...</p>
        )}
      </ul>
    </div>
  );
};

export default TopUsers;
